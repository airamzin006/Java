package sobreescrita;

public class Gato extends Andre {

    @Override
    public String emiteSom() {
        return "Meow Meow";
    }
}
