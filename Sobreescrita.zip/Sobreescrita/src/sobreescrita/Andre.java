package sobreescrita;

public class Andre {

    public String emiteSom() {
        return "Qualquer som";
    }
}
