package sobreescrita;

public class Galinha extends Andre{

    @Override
    public String emiteSom() {
        return "Pó pó pó";
    }
}
