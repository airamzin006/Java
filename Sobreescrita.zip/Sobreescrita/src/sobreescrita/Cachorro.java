package sobreescrita;

public class Cachorro extends Andre {

    @Override
    public String emiteSom() {
        return "Rulf rulf";
    }
}
