package sobreescrita;

public class Sobreescrita {

    public static void main(String[] args) {
        Andre a1 = new Andre();
        Cachorro andre = new Cachorro();
        Gato airam = new Gato();
        Galinha bibia = new Galinha();
    
        System.out.println("Som do animal: "+a1.emiteSom());
        System.out.println("Som do cachorro: "+andre.emiteSom());
        System.out.println("Som do gato: "+airam.emiteSom());
        System.out.println("Som da galinha: "+bibia.emiteSom());
    }
}
