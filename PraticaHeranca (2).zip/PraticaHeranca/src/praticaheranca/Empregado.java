package praticaheranca;

public class Empregado {

    private int codigo;
    private String nome;
    private String email;
    protected double salario;

    public Empregado(int cod, String nom, String eml, double sal) {
        this.codigo = cod;
        this.nome = nom;
        this.email = eml;
        this.salario = sal;

    }

    public double getSalario() {
        return this.salario;
    }

    public double aumentoSalarial(double percentual){
        return this.salario += this.salario * (percentual/100);
    }
}
