package praticaheranca;

public class Chefe extends Empregado {

    private double beneficio;

    public Chefe(int cod, String nom, String eml, double sal, double benef) {
        super(cod, nom, eml, sal);
        this.beneficio = benef;
    }

    @Override
    public double aumentoSalarial(double percentual) {
        return this.salario += this.salario * (percentual / 100) + this.beneficio;
    }

}
