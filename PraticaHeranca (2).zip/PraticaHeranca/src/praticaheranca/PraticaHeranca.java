package praticaheranca;

public class PraticaHeranca {

    public static void main(String[] args) {
    
        Empregado emp1 = new Empregado(1, "Henrique", "henriquecalvo@gmail.com", 1500);
        Chefe chefin = new Chefe (6, "Airam", "airam@gmail.com", 3000, 500);
        Estagiario andre = new Estagiario(3, "André", "andrezin@gmail.com", 2000, 200);
    }
}
