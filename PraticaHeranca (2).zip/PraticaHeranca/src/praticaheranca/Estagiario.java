package praticaheranca;

public class Estagiario extends Empregado {

    private double descontos;

    public Estagiario(int cod, String nom, String eml, double sal, double desc) {
        super(cod, nom, eml, sal);
        this.descontos = desc;
    }
    
    public double aumentoSalarial(double percentual){
    return this.salario += this.salario * (percentual/100) - this.descontos;
    }
    
}
