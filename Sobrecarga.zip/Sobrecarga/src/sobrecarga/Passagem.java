package sobrecarga;

public class Passagem {

    private double valor, imposto, seguro;

    public double calcularPreco(double valor, double imposto) {
        this.valor = valor;
        this.imposto = imposto;
        return this.valor + this.imposto;
    }

    public double calcularPreco(double valor, double imposto, double seguro) {
        this.valor = valor;
        this.imposto = imposto;
        this.seguro = seguro;
        return this.valor + this.imposto + this.seguro;
    }
}
