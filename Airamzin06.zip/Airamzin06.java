
package airamzin06;

public class Airamzin06 {

    public static void main(String[] args) {
    //   testando exercício 1
    Bola jabulani = new Bola("amarelo", "couro de dinossauro", 69);
    System.out.println("A cor da bola é: " +jabulani.mostrarCor());
    jabulani.trocarCor("rosa");
    System.out.println("A nova cor da bola é: " +jabulani.mostrarCor());
    System.out.println("A bola é feita de " +jabulani.mostrarMaterial() +"e tem " +jabulani.mostrarCircunferencia() +"cm de circunferência. \n");
    
    
    //   testando exercício 2
    Quadrado gigi= new Quadrado( 50 );
    System.out.println("O lado desse quadrado mede:" +gigi.retornarLado()+"cm.");
    gigi.mudarLado(60);
    System.out.println("Agora esse quadrado mede:" +gigi.retornarLado()+"cm.");
    System.out.println("A área desse quadrado é de:" +gigi.calcArea()+"cm²");
    }
 
}
