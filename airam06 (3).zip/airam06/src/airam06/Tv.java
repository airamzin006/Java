package airam06;

public class Tv {

    private int canal;
    private int volume;

    public Tv(int can, int vol) {
        this.canal = can;
        this.volume = vol;
    }

    public int setCanal(int can) {
        this.canal = can;
        if (this.canal>150){
            System.out.println("O canal de número máximo é o 150°");
            return 0;
        }
        return this.canal;
    }

    public int setVolume(int vol) {
        this.volume = vol;
        if ( this.volume>100){
            System.out.println("O volume máximo é 100");
            return 0;
        }
        return this.volume;
    }
}
