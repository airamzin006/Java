
package airam06;

public class Quadrado {
    private int lado;
    
    public Quadrado(int l){
    this.lado=l;
    }
    
    public void trocarLado(int l2){
    this.lado=l2;
    }
    
    public int mostrarLado(){
    return this.lado;
    }
    
    public int calcArea(){
    return (lado*lado);
    }
}
