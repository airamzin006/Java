
package airam06;

public class Pessoa {
    private String nome;
    private int idade;
    private double peso;
    private double altura;
    
    public Pessoa(String nom,int ida, double pes, double alt ){
    this.nome=nom;
    this.idade=ida;
    this.peso=pes;
    this.altura=alt;
    }
    
    public int pessoaEnvelhece(){
        this.idade ++;
        return this.idade;
        }
    
    public double pessoaEngorda(){
        this.peso = this.peso+1;
        return this.peso;
    }
    
    public double pessoaEmagrece(){
        this.peso = this.peso -1;
        return this.peso;
    }
    
    public double pessoaCresce(){
        this.idade ++;
        if(this.idade <21)
            this.altura +=0.05;
        return this.altura;
    }
}
