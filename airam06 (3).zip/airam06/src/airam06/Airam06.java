package airam06;

import java.util.Scanner;

public class Airam06 {

    public static void main(String[] args) {

//      Testando exercicios herança.
        Scanner teclado = new Scanner(System.in);
        Vaiculos minivan = new Vaiculos(7, 9, 10);
        Vaiculos sportcar = new Vaiculos(12, 98, 5);
        Moto moto = new Moto(2, 10, 45, "BMW");

        System.out.print("Minivan pode transportar " + minivan.get_passageiros() + " passageiros,");
        System.out.println("com uma autonomia de " + minivan.calcular_consumo() + " quilômetros.");

        System.out.print("Sport car pode transportar " + sportcar.get_passageiros() + " passageiros, ");
        System.out.println("com uma autonomia de " + sportcar.calcular_consumo() + " quilômetros.");

        System.out.print("Moto " + moto.get_marca() + " pode transporrtar " + moto.get_passageiros() + " passageiros, ");
        System.out.println("com uma autonomia de " + moto.calcular_consumo() + " quilômetros");
        System.out.println("=========================================================================================================================================");

//      LISTA DE EXERCÍCIOS 1 – CLASSES E MÉTODOS 
//      Classe Bola
        Bola brazuka = new Bola("verde", 62.5, "couro");
        System.out.println("A cor dessa bola é " + brazuka.mostrarCor() + ", ela mede" + brazuka.mostrarCirc() + "cm e é feita de " + brazuka.mostrarMaterial() + ".");
        brazuka.trocarCor("Roxa");
        System.out.println("Agora essa bola é " + brazuka.mostrarCor() + ".");
        System.out.println("=========================================================================================================================================");

//      Classe Quadrado
        Quadrado oivida = new Quadrado(27);
        System.out.println("Os lados desse quadrado medem: " + oivida.mostrarLado() + "cm.");
        oivida.trocarLado(14);
        System.out.println("Agora os lados desse quadrado medem: " + oivida.mostrarLado() + "cm. E sua área é de:" + oivida.calcArea() + "cm².");
        System.out.println("=========================================================================================================================================");

//      Classe Pessoa
        System.out.println("Insira seu nome:");
        String nom = teclado.nextLine();

        System.out.println("Insira sua idade:");
        int ida = teclado.nextInt();

        System.out.println("Insira seu peso:");
        double pes = teclado.nextDouble();

        System.out.println("Insira sua altura:");
        double alt = teclado.nextDouble();

        System.out.println(nom + "," + "você tem " + ida + " anos,pesa " + pes + " quilos e tem " + alt + "cm de altura.");
        Pessoa p = new Pessoa(nom, ida, pes, alt);

        System.out.println("Parabéns " + nom + ", você envelheceu, agora está com " + p.pessoaEnvelhece() + "anos, e com isso, está medindo" + p.pessoaCresce() + "cm.");
        System.out.println("=========================================================================================================================================");
//      classe tv

        System.out.println("Coloque o canal da tv:");
        int can = teclado.nextInt();
        if (can < 0 && can > 100) {
            System.out.println("O canal de número máximo é o 150°");
            can = teclado.nextInt();
        }

        System.out.println("Coloque o volume da tv:");
        int vol = teclado.nextInt();
        if (vol < 1 && vol > 150) {
            System.out.print("O volume máximo é 100, digite novamente");
            vol = teclado.nextInt();
        }
        Tv tvzinha = new Tv(can, vol);

        System.out.println("Você está assistindo ao canal " + can + ", com volume de " + vol + ".");

        System.out.println("Trocar canal:");
        can = teclado.nextInt();
        
        System.out.println("Trocrar volume:");
        vol = teclado.nextInt();
        
        int canalzinho = tvzinha.setCanal(can);
        
        while (canalzinho==0){
            System.out.println("Digite o canal novamente.");
            can = teclado.nextInt();
            canalzinho = tvzinha.setCanal(can);
        }
        
        int voluminho = tvzinha.setVolume(vol);
        
        while (voluminho==0){
            System.out.println("Digite o canal novamente.");
            vol = teclado.nextInt();
            voluminho = tvzinha.setVolume(vol);
        }
        
    }
}
