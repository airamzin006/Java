
package airam06;

public class Airam06 {


    public static void main(String[] args) {
        Vaiculos minivan = new Vaiculos(7, 9, 10);
        Vaiculos sportcar = new Vaiculos(12, 98 , 5);
        Moto moto = new Moto (2, 10, 45, "BMW");
        System.out.print("Minivan pode transportar " +minivan.get_passageiros()+" passageiros,");
        System.out.println("com uma autonomia de " +minivan.calcular_consumo()+ " quilômetros.");
        System.out.print("Sport car pode transportar " +sportcar.get_passageiros()+" passageiros, ");
        System.out.println("com uma autonomia de " +sportcar.calcular_consumo()+ " quilômetros.");
        System.out.print("Moto "+moto.get_marca()+" pode transporrtar " +moto.get_passageiros()+" passageiros, ");
        System.out.println("com uma autonomia de " +moto.calcular_consumo()+ " quilômetros");
    }
}
