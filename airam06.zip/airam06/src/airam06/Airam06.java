
package airam06;

public class Airam06 {


    public static void main(String[] args) {
        
//        Testando exercicios herança.
        
        Vaiculos minivan = new Vaiculos(7, 9, 10);
        Vaiculos sportcar = new Vaiculos(12, 98 , 5);
        Moto moto = new Moto (2, 10, 45, "BMW");
        
        System.out.print("Minivan pode transportar " +minivan.get_passageiros()+" passageiros,");
        System.out.println("com uma autonomia de " +minivan.calcular_consumo()+ " quilômetros.");
        
        System.out.print("Sport car pode transportar " +sportcar.get_passageiros()+" passageiros, ");
        System.out.println("com uma autonomia de " +sportcar.calcular_consumo()+ " quilômetros.");
        
        System.out.print("Moto "+moto.get_marca()+" pode transporrtar " +moto.get_passageiros()+" passageiros, ");
        System.out.println("com uma autonomia de " +moto.calcular_consumo()+ " quilômetros");
    
//      LISTA DE EXERCÍCIOS 1 – CLASSES E MÉTODOS 
//      Classe Bola
        Bola brazuka = new Bola("verde", 62.5,"couro");
        System.out.println("A cor dessa bola é " +brazuka.mostrarCor()+ ", ela mede"+ brazuka.mostrarCirc()+"cm e é feita de "+brazuka.mostrarMaterial()+".");
        brazuka.trocarCor("Roxa");
        System.out.println("Agora essa bola é " +brazuka.mostrarCor()+".");
//      Classe Quadrado
        Quadrado oivida = new Quadrado(27);
        System.out.println("Os lados desse quadrado medem: "+oivida.mostrarLado()+"cm.");
        oivida.trocarLado(14);
        System.out.println("Agora os lados desse quadrado medem: "+oivida.mostrarLado()+"cm. E sua área é de:"+oivida.calcArea()+"cm².");
//    Classe Pessoa
    
    }
}
