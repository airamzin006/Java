package airam06;

public class Moto extends Vaiculos {
        private String marca;
        
        public Moto(int pass, int comb, int cons, String mar){
            super(pass, comb, cons);
            this.marca=mar;
        }
        public String get_marca(){
            return this.marca;
        }
}
