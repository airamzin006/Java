package airam06;

public class Vaiculos {
        private int passageiros;
        private int combustivel;
        private int consumo;
    
    public Vaiculos(int pass, int comb, int cons){
        this.passageiros=pass;
        this.combustivel=comb;
        this.consumo=cons;
    }
    public int get_passageiros(){
        return this.passageiros;
    }
    public int calcular_consumo(){
        return (this.combustivel*this.consumo);
    }
}
