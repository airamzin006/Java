
package airam06;

public class Bola {
   private String cor;
   private Double circunferencia;
   private String material;
   
   public Bola( String c, Double circ, String mate){
       this.cor=c;
       this.circunferencia=circ;
       this.material=mate; 
   }
   
   public void trocarCor(String c2){
    this.cor=c2;
   }
   
   public String mostrarCor(){
   return this.cor;
   } 
   
   public Double mostrarCirc(){
   return this.circunferencia;
   }
   
   public String mostrarMaterial(){
   return this.material;
   }
}
